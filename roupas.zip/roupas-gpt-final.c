#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

#define NUM_ROUPAS 10
#define NUM_LAVADORAS 2
#define NUM_SECADORAS 3
#define NUM_DOBRADORAS 1

pthread_mutex_t mutex_lavar[NUM_LAVADORAS];
pthread_mutex_t mutex_secar[NUM_SECADORAS];
pthread_mutex_t mutex_dobrar[NUM_DOBRADORAS];
pthread_cond_t cond_secar[NUM_SECADORAS];
pthread_cond_t cond_dobrar[NUM_DOBRADORAS];

int roupas_lavadas = 0;
int roupas_secas = 0;
int roupas_dobradas = 0;

void *lavar(void *arg) {
    int id = *(int *)arg;
    for (int i = id; i < NUM_ROUPAS; i += NUM_LAVADORAS) {
        pthread_mutex_lock(&mutex_lavar[id]);
        printf("Lavando a roupa %d na lavadora %d\n", i, id);
        roupas_lavadas++;
        printf("Roupa %d lavada na lavadora %d\n", i, id);
        pthread_mutex_unlock(&mutex_lavar[id]);

        usleep(rand() % 2000000 + 1000000); // Simula o tempo de lavagem

        pthread_mutex_lock(&mutex_secar[id % NUM_SECADORAS]);
        pthread_cond_signal(&cond_secar[id % NUM_SECADORAS]);
        pthread_mutex_unlock(&mutex_secar[id % NUM_SECADORAS]);
    }
    return NULL;
}

void *secar(void *arg) {
    int id = *(int *)arg;
    for (int i = id; i < NUM_ROUPAS; i += NUM_SECADORAS) {
        pthread_mutex_lock(&mutex_secar[id]);
        while (roupas_lavadas <= i) {
            pthread_cond_wait(&cond_secar[id], &mutex_secar[id]);
        }
        printf("Colocando a roupa %d na secadora %d\n", i, id);
        roupas_secas++;
        printf("Roupa %d seca na secadora %d\n", i, id);
        pthread_mutex_unlock(&mutex_secar[id]);

        usleep(rand() % 2000000 + 1000000); // Simula o tempo de secagem

        pthread_mutex_lock(&mutex_dobrar[id % NUM_DOBRADORAS]);
        pthread_cond_signal(&cond_dobrar[id % NUM_DOBRADORAS]);
        pthread_mutex_unlock(&mutex_dobrar[id % NUM_DOBRADORAS]);
    }
    return NULL;
}

void *dobrar(void *arg) {
    int id = *(int *)arg;
    for (int i = id; i < NUM_ROUPAS; i += NUM_DOBRADORAS) {
        pthread_mutex_lock(&mutex_dobrar[id]);
        while (roupas_secas <= i || roupas_dobradas >= i) {
            pthread_cond_wait(&cond_dobrar[id], &mutex_dobrar[id]);
        }
        printf("Dobrando a roupa %d na dobradora %d\n", i, id);
        roupas_dobradas++;
        printf("Roupa %d dobrada na dobradora %d\n", i, id);
        pthread_mutex_unlock(&mutex_dobrar[id]);
    }
    return NULL;
}

int main() {
    pthread_t lavadoras[NUM_LAVADORAS];
    pthread_t secadoras[NUM_SECADORAS];
    pthread_t dobradoras[NUM_DOBRADORAS];

    int lavadora_ids[NUM_LAVADORAS];
    int secadora_ids[NUM_SECADORAS];
    int dobradora_ids[NUM_DOBRADORAS];

    for (int i = 0; i < NUM_LAVADORAS; i++) {
        lavadora_ids[i] = i;
        pthread_mutex_init(&mutex_lavar[i], NULL);
        if (pthread_create(&lavadoras[i], NULL, lavar,
