#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

#define NUM_THREADS 2
#define NUM_ITERATIONS 5

int buffer_lavadas = 0;
int buffer_secas = 0;

sem_t sem_secar;
sem_t sem_dobrar;
sem_t sem_buffer_lavadas;
sem_t sem_buffer_secas;

void* lavar(void* arg) {
    for(int i = 0; i < NUM_ITERATIONS; i++) {
        printf("Lavando roupas...\n");
        sleep(2);
        sem_wait(&sem_buffer_lavadas);
        buffer_lavadas++;
        printf("Roupas lavadas! Total no buffer: %d\n", buffer_lavadas);
        sem_post(&sem_buffer_lavadas);
        sem_post(&sem_secar);
    }
    return NULL;
}

void* secar(void* arg) {
    for(int i = 0; i < NUM_ITERATIONS; i++) {
        sem_wait(&sem_secar);
        sem_wait(&sem_buffer_lavadas);
        if (buffer_lavadas > 0) {
            buffer_lavadas--;
            printf("Secando roupas...\n");
            sleep(2);
            sem_wait(&sem_buffer_secas);
            buffer_secas++;
            printf("Roupas secas! Total no buffer: %d\n", buffer_secas);
            sem_post(&sem_buffer_secas);
            sem_post(&sem_dobrar);
        }
        sem_post(&sem_buffer_lavadas);
    }
    return NULL;
}

void* dobrar(void* arg) {
    for(int i = 0; i < NUM_ITERATIONS; i++) {
        sem_wait(&sem_dobrar);
        sem_wait(&sem_buffer_secas);
        if (buffer_secas > 0) {
            buffer_secas--;
            printf("Dobrando roupas...\n");
            sleep(2);
            printf("Roupas dobradas!\n");
        }
        sem_post(&sem_buffer_secas);
    }
    return NULL;
}

int main() {
    pthread_t thread_lavar[NUM_THREADS], thread_secar[NUM_THREADS], thread_dobrar[NUM_THREADS];

    sem_init(&sem_secar, 0, 0);
    sem_init(&sem_dobrar, 0, 0);
    sem_init(&sem_buffer_lavadas, 0, 1);
    sem_init(&sem_buffer_secas, 0, 1);

    for(int i = 0; i < NUM_THREADS; i++) {
        pthread_create(&thread_lavar[i], NULL, lavar, NULL);
        pthread_create(&thread_secar[i], NULL, secar, NULL);
        pthread_create(&thread_dobrar[i], NULL, dobrar, NULL);
    }

    for(int i = 0; i < NUM_THREADS; i++) {
        pthread_join(thread_lavar[i], NULL);
        pthread_join(thread_secar[i], NULL);
        pthread_join(thread_dobrar[i], NULL);
    }

    sem_destroy(&sem_secar);
    sem_destroy(&sem_dobrar);
    sem_destroy(&sem_buffer_lavadas);
    sem_destroy(&sem_buffer_secas);

    return 0;
}