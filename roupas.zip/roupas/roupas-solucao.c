#include <stdlib.h>
#include <stdio.h>
#include <sys/time.h>
#include <pthread.h>

#include "clothing.h"
#include "buffer.h"

/*
 * Variáveis globais
 *
 */
// conjunto de roupas (alocado dinamicamente) - use roupas[i] para acessar a
// i-ésima roupa
void **roupas;
  
// número total de roupas a serem processadas
unsigned long num_roupas = 0;

// usado apenas na versão paralela
#ifndef SEQUENTIAL
static unsigned int threads_lavadoras = 0;
static unsigned int threads_secadoras = 0;
static unsigned int threads_guardadoras = 0;

pthread_cond_t lavadas_cheio, lavadas_vazio, secas_cheio, secas_vazio = PTHREAD_COND_INITIALIZER;
pthread_mutex_t lavaLock, secaLock = PTHREAD_MUTEX_INITIALIZER;

buffer_t *lavadas;
buffer_t *secas;

void *thread_lavadora(void *arg)
{
  int my_id = (int)arg;
  int bloco = num_roupas/threads_lavadoras;
  int my_start = my_id*bloco;
  int my_end = (my_id == threads_lavadoras-1) ? num_roupas : (my_id + 1)*bloco;

  for (long i=my_start; i<my_end; i++) {
    cl_lavar(roupas[i]);

    pthread_mutex_lock(&lavaLock);

    while (buffer_is_full(lavadas))
      pthread_cond_wait(&lavadas_cheio, &lavaLock);
  
    buffer_put(lavadas, roupas[i]);

    pthread_cond_signal(&lavadas_vazio);

    pthread_mutex_unlock(&lavaLock);
  }

  return NULL;
}

void *thread_secadora(void *arg)
{ 
  int my_id = (int)arg;
  int bloco = num_roupas/threads_secadoras;
  int my_start = my_id*bloco;
  int my_end = (my_id == threads_secadoras-1) ? num_roupas : (my_id + 1)*bloco;

  for (long i=my_start; i<my_end; i++) {
    pthread_mutex_lock(&lavaLock);

    while (buffer_is_empty(lavadas))
        pthread_cond_wait(&lavadas_vazio, &lavaLock);

    clothing_t *tmp = buffer_get(lavadas);

    pthread_cond_signal(&lavadas_cheio);
    
    pthread_mutex_unlock(&lavaLock);
//
    cl_secar(tmp);

    pthread_mutex_lock(&secaLock);

    while (buffer_is_full(secas))
      pthread_cond_wait(&secas_cheio, &secaLock);

    buffer_put(secas, tmp);

    pthread_cond_signal(&secas_vazio);

    pthread_mutex_unlock(&secaLock);
  }

  return NULL;
}

void *thread_guardadora(void *arg)
{
  int my_id = (int)arg;
  int bloco = num_roupas/threads_guardadoras;
  int my_start = my_id*bloco;
  int my_end = (my_id == threads_guardadoras-1) ? num_roupas : (my_id + 1)*bloco;

  for (long i=my_start; i<my_end; i++) {
    pthread_mutex_lock(&secaLock);

    while (buffer_is_empty(secas))
      pthread_cond_wait(&secas_vazio, &secaLock);
    
    clothing_t *tmp = buffer_get(secas);

    pthread_cond_signal(&secas_cheio);

    pthread_mutex_unlock(&secaLock);
    
    cl_guardar(tmp);
  }

  return NULL;
}
#endif

/*
 * Input parameters:
 *
 *  <#items> <#washers> <#dryers> <#folders>
 */
int main(int argc, char *argv[])
{
  struct timeval start, end;
  float elapsed_time;
  long i;
  pthread_t *thread_handles;

#ifdef SEQUENTIAL
  if (argc <=1) {
    fprintf(stderr, "Invalid parameter number: use <#items>\n");
    exit(-1);
  }
#else
  if (argc <= 4) {
    fprintf(stderr, "Invalid parameter number: use <#items> <#washers> <#dryers> <#folders> \n");
    exit(-1);
  }
#endif

  num_roupas = strtol(argv[1], NULL, 10);
  
  fprintf(stdout, "Numero de roupas = %u\n", num_roupas);
  
#ifndef SEQUENTIAL
  threads_lavadoras = strtol(argv[2], NULL, 10);
  threads_secadoras = strtol(argv[3], NULL, 10);
  threads_guardadoras = strtol(argv[4], NULL, 10);

  lavadas = buffer_create(num_roupas/5);
  secas = buffer_create(num_roupas/5);
  
  int thread_count = threads_lavadoras+threads_secadoras+threads_guardadoras;
  thread_handles = malloc(thread_count*sizeof(pthread_t));
  
  fprintf(stdout, "Threads:\n" 
                            "Lavadoras  : %u\n" 
                            "Secadoras  : %u\n" 
                            "Guardadoras: %u\n",
                            threads_lavadoras, 
                            threads_secadoras,
                            threads_guardadoras);

#endif /* SEQUENTIAL */

  // gera roupas sujas com base em parametro passado pelo usuario
  roupas = (void **)malloc(sizeof(void **)*num_roupas);

  for (i=0; i<num_roupas; i++)
    roupas[i] = (void *)cl_criar(CL_SUJA);

  gettimeofday(&start, NULL);
 
#ifndef SEQUENTIAL
  for (i=0; i<threads_lavadoras; i++) {
    if (pthread_create(&thread_handles[i], NULL, thread_lavadora, (void *)i) != 0) {
      fprintf(stderr, "Nao consegui criar uma thread lavadora\n");
      exit(-1);
    }
  }
  for (i=0; i<threads_secadoras; i++) {
    if (pthread_create(&thread_handles[i+threads_lavadoras], NULL, thread_secadora, (void *)i) != 0) {
      fprintf(stderr, "Nao consegui criar uma thread secadora\n");
      exit(-1);
    }
  }
  for (i=0; i<threads_guardadoras; i++) {
    if (pthread_create(&thread_handles[i+threads_lavadoras+threads_secadoras], NULL, thread_guardadora, (void *)i) != 0) {
      fprintf(stderr, "Nao consegui criar uma thread guardadora\n");
      exit(-1);
    }
  }
 
  /* JOIN */
  for (i=0; i<thread_count; i++)
  {
    pthread_join(thread_handles[i], NULL);
  }
#else
  // versão sequencial
  // processa as roupas: lava, seca, guarda  -- sequencial
  for (i=0; i<num_roupas; i++) {
    cl_lavar(roupas[i]);
    cl_secar(roupas[i]);
    cl_guardar(roupas[i]);
  }
#endif /* SEQUENTIAL */ 
  
  gettimeofday(&end, NULL);


  // checa se roupas estão guardadas
  for (i=0; i<num_roupas; i++)
    if (!cl_is_status(roupas[i], CL_GUARDADA)) {
      fprintf(stderr, "Roupa [%d] não foi guardada!\n", i);
      exit(-1);
    }

  fprintf(stdout, "Todas as roupas foram guardadas corretamente!\n");

  // desaloca roupas
  for (i=0; i<num_roupas; i++)
    cl_apagar(roupas[i]);

  elapsed_time = (end.tv_sec - start.tv_sec) + (end.tv_usec - start.tv_usec) / 1000000.0;
  fprintf(stdout, "Elapsed time: %g s\n", elapsed_time); 

  return 0;
}
