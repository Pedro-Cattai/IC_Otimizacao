#include <stdio.h>
#include <omp.h>
#include <sys/time.h>

#define N 14

unsigned long long solutions = 0;

void solveNQueens(int col, unsigned long long rowMask, unsigned long long ldMask, unsigned long long rdMask) {
    if (col == N) {
        #pragma omp atomic
        solutions++;
        return;
    }

    unsigned long long safeSpots = ((1ULL << N) - 1) & ~(rowMask | ldMask | rdMask);

    while (safeSpots) {
        unsigned long long spot = -safeSpots & safeSpots;
        safeSpots ^= spot;
        solveNQueens(col + 1, rowMask | spot, (ldMask | spot) << 1, (rdMask | spot) >> 1);
    }
}

int main() {
      struct timeval start, stop;
  gettimeofday(&start, NULL);

    #pragma omp parallel
    {
        #pragma omp single
        {
            solveNQueens(0, 0, 0, 0);
        }
    }
      gettimeofday(&stop, NULL); 


    fprintf(stdout, "Número total de soluções para %d rainhas no tabuleiro %dx%d é: %llu\n", N, N, N, solutions);
  
  double t = (((double)(stop.tv_sec)*1000.0  + (double)(stop.tv_usec / 1000.0)) - \
                   ((double)(start.tv_sec)*1000.0 + (double)(start.tv_usec / 1000.0)));

  fprintf(stdout, "Tempo decorrido = %g ms\n", t);

    return 0;
}