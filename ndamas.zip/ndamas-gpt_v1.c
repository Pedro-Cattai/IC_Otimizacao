#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <sys/time.h>

#define N 14

int isSafe(int board[N][N], int row, int col) {
    int i, j;

    // Verifique a linha à esquerda
    for (i = 0; i < col; i++) {
        if (board[row][i])
            return 0;
    }

    // Verifique a diagonal superior esquerda
    for (i = row, j = col; i >= 0 && j >= 0; i--, j--) {
        if (board[i][j])
            return 0;
    }

    // Verifique a diagonal inferior esquerda
    for (i = row, j = col; i < N && j >= 0; i++, j--) {
        if (board[i][j])
            return 0;
    }

    return 1;
}

void solveNQueens(int board[N][N], int col, int* count) {
    if (col >= N) {
        #pragma omp atomic
        (*count)++;
        return;
    }

    #pragma omp parallel
    {
        #pragma omp single nowait
        for (int i = 0; i < N; i++) {
            if (isSafe(board, i, col)) {
                board[i][col] = 1;
                solveNQueens(board, col + 1, count);
                board[i][col] = 0;
            }
        }
    }
}

int main() {
    int board[N][N] = {0};
    int solutions = 0;
  struct timeval start, stop;

  gettimeofday(&start, NULL);

    solveNQueens(board, 0, &solutions);

      gettimeofday(&stop, NULL); 

  fprintf(stdout, "Número total de soluções: %d\n", solutions);
  
  double t = (((double)(stop.tv_sec)*1000.0  + (double)(stop.tv_usec / 1000.0)) - \
                   ((double)(start.tv_sec)*1000.0 + (double)(start.tv_usec / 1000.0)));

  fprintf(stdout, "Tempo decorrido = %g ms\n", t);
    return 0;
}
