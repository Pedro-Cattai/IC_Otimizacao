#include <stdio.h>
#include <omp.h>
#include <sys/time.h>

#define N 14

int board[N][N];
int solutions = 0;

int is_safe(int row, int col) {
    int i, j;

    // Check if there is a queen in the same column
    for (i = 0; i < row; i++) {
        if (board[i][col] == 1) {
            return 0;
        }
    }

    // Check if there is a queen in the upper left diagonal
    for (i = row, j = col; i >= 0 && j >= 0; i--, j--) {
        if (board[i][j] == 1) {
            return 0;
        }
    }

    // Check if there is a queen in the upper right diagonal
    for (i = row, j = col; i >= 0 && j < N; i--, j++) {
        if (board[i][j] == 1) {
            return 0;
        }
    }

    return 1;
}

void solve_n_queens(int row) {
    int col;

    if (row == N) {
        // Print the solution
        #pragma omp critical
        {
            solutions++;
            /*printf("Solution:\n");
            for (int i = 0; i < N; i++) {
                for (int j = 0; j < N; j++) {
                    printf("%d ", board[i][j]);
                }
                printf("\n");
            }
            printf("\n");*/
        }
    } else {
        for (col = 0; col < N; col++) {
            if (is_safe(row, col)) {
                board[row][col] = 1;
                solve_n_queens(row + 1);
                board[row][col] = 0;
            }
        }
    }
}

int main() {
    int i;
      struct timeval start, stop;

    // Initialize the board
    for (i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            board[i][j] = 0;
        }
    }

    gettimeofday(&start, NULL);

    // Solve the N-Queens problem in parallel
    #pragma omp parallel
    {
        #pragma omp single
        solve_n_queens(0);
    }

    gettimeofday(&stop, NULL); 

    double t = (((double)(stop.tv_sec)*1000.0  + (double)(stop.tv_usec / 1000.0)) - \
                   ((double)(start.tv_sec)*1000.0 + (double)(start.tv_usec / 1000.0)));

  fprintf(stdout, "Tempo decorrido = %g ms\n", t);

    printf("Solutions: %d\n", solutions);

    return 0;
}
