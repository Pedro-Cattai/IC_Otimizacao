#include <stdio.h>
#include <omp.h>

#define N 14

int solutions = 0;

int is_safe(int board[N][N], int row, int col) {
    int i, j;

    for (i = 0; i < row; i++) {
        if (board[i][col]) {
            return 0;
        }
    }

    for (i = row, j = col; i >= 0 && j >= 0; i--, j--) {
        if (board[i][j]) {
            return 0;
        }
    }

    for (i = row, j = col; i >= 0 && j < N; i--, j++) {
        if (board[i][j]) {
            return 0;
        }
    }

    return 1;
}

void solve_n_queens(int board[N][N], int row) {
    if (row == N) {
        #pragma omp atomic
        solutions++;
        return;
    }

    for (int col = 0; col < N; col++) {
        if (is_safe(board, row, col)) {
            board[row][col] = 1;
            solve_n_queens(board, row + 1);
            board[row][col] = 0;
        }
    }
}

int main() {
    double start = omp_get_wtime();

    #pragma omp parallel for
    for (int i = 0; i < N; i++) {
        int board[N][N] = {0};
        board[0][i] = 1;
        solve_n_queens(board, 1);
    }

    double end = omp_get_wtime();
    double time = end - start;

    printf("Solutions: %d\n", solutions);
    printf("Time: %f ms\n", time*1000);

    return 0;
}