#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <sys/time.h>
#include <omp.h>

int main(int argc, char *argv[])
{
    struct timeval start, end;
    double t, sum;
    int i, j, k, tam;

    if (argc < 2) {
        printf("É necessário especificar o tamanho da matriz\n");
        exit(-1);
    }

    srand(0);

    tam = atoi(argv[1]);

    double **ma = (double **)malloc(tam * sizeof(double*));
    for (int i = 0; i < tam; i++) 
        ma[i] = (double *)malloc(tam * sizeof(double));

    double **mb = (double **)malloc(tam * sizeof(double*));
    for (int i = 0; i < tam; i++) 
        mb[i] = (double *)malloc(tam * sizeof(double));

    double **mfim = (double **)malloc(tam * sizeof(double*));
    for (int i = 0; i < tam; i++) 
        mfim[i] = (double *)malloc(tam * sizeof(double));

    if (ma == NULL || mb == NULL || mfim == NULL) {
        fprintf(stderr, "Out of memory");
        exit(-1);
    }

    for (i=0;i<tam;i++)
        for (j=0;j<tam;j++){
            ma[i][j] = (fmod (rand(), 50.111));
            mb[i][j] = (fmod (rand(), 50.111));
        }

    gettimeofday(&start, NULL);

    for (i = 0; i < tam; i++) {
        for (j = 0; j < tam; j++) {
            mfim[i][j] = 0.0;
            #pragma omp simd
            for (k = 0; k < tam; k++) {
                mfim[i][j] += ma[i][k] * mb[k][j];
            }
        }
    }

    gettimeofday(&end, NULL);
    t = (double) (end.tv_sec-start.tv_sec) + (double) (end.tv_usec-start.tv_usec) / 1000000;
    printf("Tempo: %f segundos\n", t);

    return 0;
}